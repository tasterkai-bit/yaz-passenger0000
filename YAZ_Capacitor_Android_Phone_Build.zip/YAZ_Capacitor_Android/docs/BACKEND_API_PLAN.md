# YAZ Passenger — backend contract (initial proposal)

This is a proposed integration plan, not an existing or deployed server.

## Required services before public launch
- HTTPS API gateway and backend service.
- PostgreSQL (users, trips, saved places, payments ledger) with migrations and backups.
- Authentication provider or secure OTP service; access tokens short-lived, refresh tokens protected.
- Maps/geocoding/routing provider with key restrictions and billing limits.
- Driver app/admin dispatch service to accept, assign, cancel and complete trips.
- Payment provider integration; never store card PAN/CVV in YAZ systems.
- Push notification service, monitoring, crash reporting, audit logs, rate limits and abuse protection.
- Privacy policy, terms, retention/deletion process, consent and applicable transport/payment compliance.

## Suggested REST endpoints
- `POST /v1/auth/otp/request` — request a one-time code.
- `POST /v1/auth/otp/verify` — verify code and create a session.
- `GET /v1/me` / `PATCH /v1/me` — passenger profile.
- `GET /v1/places` / `POST /v1/places` / `DELETE /v1/places/{id}` — saved places.
- `POST /v1/quotes` — origin, destination, ride class; returns fare estimate and ETA.
- `POST /v1/trips` — create a trip request using an idempotency key.
- `GET /v1/trips/{id}` — trip state, assigned driver and ETA.
- `POST /v1/trips/{id}/cancel` — cancellation subject to policy.
- `GET /v1/trips` — passenger trip history.
- `POST /v1/payments/intent` and `GET /v1/payments/{id}` — payment provider flow/status.
- `GET /v1/wallet` / `GET /v1/wallet/transactions` — wallet balance and ledger (server-authoritative).
- `POST /v1/devices` — register push notification token.

## Core data entities
- Passenger: id, verified phone, display name, status, created_at.
- SavedPlace: id, passenger_id, label, lat, lng, address.
- Trip: id, passenger_id, driver_id nullable, origin/destination coordinates, fare_quote, final_fare, status, timestamps.
- Payment: id, trip_id nullable, provider_reference, amount, currency, status; no raw card details.
- WalletLedgerEntry: id, passenger_id, amount, currency, type, reference, created_at; immutable ledger entries.

## Security rules
- Enforce authorization and ownership checks on every object.
- Never trust fare, wallet balance, role, or trip state sent by the client.
- Keep API keys and provider secrets on the server; mobile app keys are public and must be restricted.
- Require TLS, request validation, rate limiting, idempotency for payment/trip creation, secure logs and backups.
- Use sandbox payment credentials until end-to-end testing is complete.
