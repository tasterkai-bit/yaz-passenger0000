import { defineConfig } from 'vite';
import { resolve } from 'node:path';

export default defineConfig({
  build: {
    rollupOptions: {
      input: resolve(process.cwd(), 'www/index.html')
    },
    outDir: 'dist',
    emptyOutDir: true
  }
});
